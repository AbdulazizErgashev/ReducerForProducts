import React, { useReducer } from "react";
import Shaftoli from "../img/shaftoli.png";
import Bodring from "../img/bodring.png";
import Yongoq from "../img/yongoq.png";
import Broklin from "../img/brokliyn.png";
import Nok from "../img/nok.png";
import { FaRegHeart } from "react-icons/fa";
import { MdOutlineShoppingCart } from "react-icons/md";

export default function Homework() {
  const reducer = (state, action) => {
    let { type, payload } = action;

    switch (type) {
      case "plus":
        // let element = state.products.find((item) => item.id === payload);
        return {
          ...state,
          products: state.products.map((item) =>
            item.id === payload ? { ...item, count: item.count + 1 } : item
          ),
        };

      case "minus":
        let min_elem = state.products.find((item) => item.id === payload);

        if (min_elem.count > 0) {
          return {
            ...state,
            products: state.products.map((item) =>
              item.id === payload ? { ...item, count: item.count - 1 } : item
            ),
          };
        } else {
          window.alert("noldan kamaymaydi");
        }

      case "liked":
        return {
          ...state,
          products: state.products.map((item) =>
            item.id === payload ? { ...item, liked: !item.liked } : item
          ),
        };

      case "addToCart":
        const yangiItem = state.products.find(
          (products) => products.id === payload
        );
        return {
          ...state,
          cart: [...state.cart, yangiItem],
          // ...state,
          // cart: [...state.cart, payload],
          // products: state.products.map((item) =>
          //   item.id === payload ? { ...item, cart: !cart } : cart
          // ),
        };

      default:
        return state;
    }
  };

  let [reduceData, dispatch] = useReducer(reducer, {
    products: [
      {
        id: 1,
        skidka: "15%Off",
        img: Shaftoli,
        quality: "Available(in stock)",
        title: "Fresh organic apricot",
        newPrice: "$12",
        oldPrice: "$15",
        count: 0,
        liked: false,
      },
      {
        id: 2,
        skidka: "15%Off",
        img: Bodring,
        quality: "Available(in stock)",
        title: "Cucumber",
        newPrice: "$12",
        oldPrice: "$15",
        count: 0,
        liked: false,
      },
      {
        id: 3,
        skidka: "15%Off",
        img: Yongoq,
        quality: "Available(in stock)",
        title: "Hazelnuts filbert nut",
        newPrice: "$12",
        oldPrice: "$15",
        count: 0,
        liked: false,
      },
      {
        id: 4,
        skidka: "15%Off",
        img: Broklin,
        quality: "Available(in stock)",
        title: "Raw Broccoli",
        newPrice: "$12",
        oldPrice: "$15",
        count: 0,
        liked: false,
      },
      {
        id: 5,
        skidka: "15%Off",
        img: Nok,
        quality: "Available(in stock)",
        title: "Organic quince",
        newPrice: "$12",
        oldPrice: "$15",
        count: 0,
        liked: false,
      },
    ],

    cart: [],
  });

  return (
    <>
      <div className="container">
        <div className="grid grid-cols-5 gap-x-3 py-10">
          {reduceData.products.map((item) => (
            <div
              className="flex flex-col items-center gap-y-3 p-5 border-2 border-[#7fad39]"
              key={item.id}
            >
              <div className="flex items-center gap-x-36">
                <h1 className="bg-[#7FAD39] text-[#fff] text-[0.75rem]/[1.9rem] font-extrabold px-2">
                  {item.skidka}
                </h1>

                <div className="bg-[#D8E6C3] rounded-full cursor-pointer">
                  <FaRegHeart
                    className={`text-[#7FAD39] p-2 text-4xl ${
                      item.liked ? "bg-red-500 text-white rounded-full" : ""
                    }`}
                    onClick={() =>
                      dispatch({ type: "liked", payload: item.id })
                    }
                  />
                </div>
              </div>
              <img src={item.img} alt="..." />
              <h1 className="text-[#aaa] text-xs font-bold">{item.quality}</h1>
              <h1 className="text-[#2A2A2A] font-semibold">{item.title}</h1>
              <div className="flex items-center gap-x-1">
                <p className="text-[#7FAD39] font-semibold">{item.newPrice}</p>
                <del className="text-[#aaa] font-semibold">{item.oldPrice}</del>
              </div>
              <div className="flex items-center gap-x-32">
                <div className="flex items-center gap-x-3">
                  <button
                    onClick={() =>
                      dispatch({ type: "minus", payload: item.id })
                    }
                    className="bg-[#2A2A2A] text-[#fff] px-3 py-1"
                  >
                    -
                  </button>
                  <p className="text-xs font-semibold">{item.count}</p>
                  <button
                    onClick={() => dispatch({ type: "plus", payload: item.id })}
                    className="bg-[#2A2A2A] text-[#fff] px-3 py-1"
                  >
                    +
                  </button>
                </div>
                <MdOutlineShoppingCart
                  className="text-[#A9A9A9] text-2xl cursor-pointer"
                  onClick={() => dispatch({ type: "addToCart", payload: item })}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
