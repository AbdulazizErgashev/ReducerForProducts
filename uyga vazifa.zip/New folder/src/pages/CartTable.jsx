import React from "react";

export default function CartTable({ cart }) {
  return (
    <div>
      <h1>cartTable</h1>
    </div>
  );
}
